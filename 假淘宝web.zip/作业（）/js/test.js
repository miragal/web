window.onload=function(){
			function log(){
				var name=document.getElementById("name").value;
				var pass=document.getElementById("password").value;
				if((name=="zhangsan")&&(pass="123456")){
					return true;
				}else{
					return false;
				}
			}
			
      		 document.getElementById("submit").onclick = function change(){
        		if(log()){
					window.location.href = "./loginsuccess.html";
					return false;
        		}
        		else{
					alert("账号或密码错误");
        		}
      		 }
}